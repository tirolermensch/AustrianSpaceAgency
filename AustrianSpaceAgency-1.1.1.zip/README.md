# AustrianSpaceAgency
A small collection of KSP Flags and Suits for the Austrian Space Agency!

You will need TextureReplacer for the Suits!

Licence: MIT


